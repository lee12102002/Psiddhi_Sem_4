"""
Auth flow tests. Uses a throwaway SQLite file per test session so this
suite never touches the real dev database seeded by scripts/seed_reference_data.py.
"""
import os
import sys
from pathlib import Path

os.environ["DATABASE_URL"] = "sqlite:///./test_qualityiq.db"

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import pytest
from fastapi.testclient import TestClient

from app.main import app
from app.db.session import Base, engine, SessionLocal
from app.db.models import User, UserRole
from app.auth.security import hash_password


@pytest.fixture(scope="module", autouse=True)
def setup_db():
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()
    db.add(User(
        username="testuser",
        email="testuser@example.com",
        password_hash=hash_password("TestPass@123"),
        role=UserRole.quality_engineer,
    ))
    db.commit()
    db.close()
    yield
    Base.metadata.drop_all(bind=engine)
    db_path = Path("test_qualityiq.db")
    if db_path.exists():
        db_path.unlink()


client = TestClient(app)


def test_health_check():
    resp = client.get("/api/health")
    assert resp.status_code == 200
    assert resp.json()["status"] == "ok"


def test_login_success():
    resp = client.post("/api/auth/login", data={"username": "testuser", "password": "TestPass@123"})
    assert resp.status_code == 200
    body = resp.json()
    assert "access_token" in body
    assert body["role"] == "quality_engineer"


def test_login_wrong_password():
    resp = client.post("/api/auth/login", data={"username": "testuser", "password": "wrong"})
    assert resp.status_code == 401


def test_login_unknown_user():
    resp = client.post("/api/auth/login", data={"username": "ghost", "password": "whatever"})
    assert resp.status_code == 401


def test_me_requires_token():
    resp = client.get("/api/auth/me")
    assert resp.status_code == 401


def test_me_with_valid_token():
    login_resp = client.post("/api/auth/login", data={"username": "testuser", "password": "TestPass@123"})
    token = login_resp.json()["access_token"]
    resp = client.get("/api/auth/me", headers={"Authorization": f"Bearer {token}"})
    assert resp.status_code == 200
    assert resp.json()["username"] == "testuser"


def test_me_with_garbage_token():
    resp = client.get("/api/auth/me", headers={"Authorization": "Bearer garbage.token.here"})
    assert resp.status_code == 401
