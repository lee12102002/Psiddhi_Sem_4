"""
Layer 1, step 1: synthetic data generator.

Produces 90 days of realistic-looking manufacturing data across the 3
products / 4 process steps / 5 inspectors already seeded, and writes it
as raw, untouched records into bronze_ingestion_log — exactly as if it
had arrived from a real plant floor system.

Design choices that make this useful for demoing the ML layer later:
  - Baseline defect rate varies by (product, step) — Assembly is
    inherently riskier than Packaging, for example.
  - Mild weekly seasonality — defect rate ticks up mid-week.
  - 3 injected anomaly windows — short spikes in one product/step's
    defect rate, so the anomaly-detection model has something real to
    find instead of pure noise.
  - ~2% of records are deliberately malformed (missing field / bad
    enum value) so the validation step downstream has something real
    to catch and reject.
  - High/critical defects probabilistically spawn a CAPA a few days
    later, some closed, some still open/overdue.
  - A daily SonarQube record, with gate failures loosely correlated to
    the same anomaly windows — ties the "engineering health" domain to
    the "process health" domain, per the original proposal's thesis.

Run from backend/: `python -m app.ingestion.generate_synthetic_data`
"""
import json
import random
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from faker import Faker

from app.db.session import SessionLocal, Base, engine
from app.db.models import (
    BronzeIngestionLog, SourceDomain, ValidationStatus,
    DimProduct, DimProcessStep, DimInspector,
)

fake = Faker()
random.seed(42)  # reproducible demo dataset

DAYS = 90
START_DATE = datetime.now(timezone.utc) - timedelta(days=DAYS)

DEFECT_CATALOG = [
    ("DEF-101", "Surface scratch", "low"),
    ("DEF-102", "Dimensional tolerance out of spec", "medium"),
    ("DEF-103", "Misaligned assembly", "high"),
    ("DEF-104", "Material contamination", "critical"),
    ("DEF-105", "Incomplete finishing", "medium"),
    ("DEF-106", "Packaging seal failure", "low"),
    ("DEF-107", "Weld/joint integrity failure", "critical"),
]

# Baseline defect rate per (product, step) — some combos are just riskier.
BASE_RATE = {
    ("PROD-A", "STEP-1"): 0.03, ("PROD-A", "STEP-2"): 0.06, ("PROD-A", "STEP-3"): 0.04, ("PROD-A", "STEP-4"): 0.02,
    ("PROD-B", "STEP-1"): 0.04, ("PROD-B", "STEP-2"): 0.07, ("PROD-B", "STEP-3"): 0.03, ("PROD-B", "STEP-4"): 0.02,
    ("PROD-C", "STEP-1"): 0.02, ("PROD-C", "STEP-2"): 0.05, ("PROD-C", "STEP-3"): 0.03, ("PROD-C", "STEP-4"): 0.015,
}

# 3 injected anomaly windows: (start_day_offset, length_days, product, step, rate_multiplier)
ANOMALY_WINDOWS = [
    (18, 4, "PROD-B", "STEP-2", 4.5),
    (47, 3, "PROD-A", "STEP-3", 3.5),
    (72, 5, "PROD-C", "STEP-1", 5.0),
]


def defect_rate_for(day_index: int, product_id: str, step_id: str) -> float:
    rate = BASE_RATE[(product_id, step_id)]

    # Mild weekly seasonality: mid-week (Wed/Thu) slightly elevated
    weekday = (START_DATE + timedelta(days=day_index)).weekday()
    if weekday in (2, 3):
        rate *= 1.25
    elif weekday in (5, 6):
        rate *= 0.7  # weekends run lighter

    for start, length, p, s, mult in ANOMALY_WINDOWS:
        if p == product_id and s == step_id and start <= day_index < start + length:
            rate *= mult

    return min(rate, 0.9)


def is_anomaly_day(day_index: int) -> bool:
    return any(start <= day_index < start + length for start, length, *_ in ANOMALY_WINDOWS)


def make_bronze_record(db, domain: SourceDomain, payload: dict, valid_shape: bool = True) -> str:
    if not valid_shape:
        # Deliberately corrupt ~2% of records so validation has real work to do.
        corruption = random.choice(["missing_field", "bad_enum"])
        if corruption == "missing_field":
            payload.pop(random.choice(list(payload.keys())), None)
        else:
            for key in ("result", "severity", "status"):
                if key in payload:
                    payload[key] = "not_a_real_value"
                    break

    row = BronzeIngestionLog(
        source_domain=domain,
        source_system="synthetic_generator",
        raw_payload=json.dumps(payload, default=str),
        validation_status=ValidationStatus.pending,
        schema_version="v1",
    )
    db.add(row)
    db.flush()
    return row.ingestion_id


def generate():
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()

    products = [p.product_id for p in db.query(DimProduct).all()]
    steps = [s.step_id for s in db.query(DimProcessStep).all()]
    inspectors = [i.inspector_id for i in db.query(DimInspector).all()]

    if not products or not steps or not inspectors:
        raise RuntimeError(
            "Dimension tables are empty. Run scripts/seed_reference_data.py first."
        )

    inspection_count = 0
    defect_count = 0
    capa_count = 0

    pending_defects = []  # (event_ts, product_id, defect_code, severity) awaiting possible CAPA

    for day_index in range(DAYS):
        day = START_DATE + timedelta(days=day_index)

        for product_id in products:
            for step_id in steps:
                rate = defect_rate_for(day_index, product_id, step_id)
                daily_inspections = random.randint(10, 22)

                for _ in range(daily_inspections):
                    inspector_id = random.choice(inspectors)
                    batch_id = f"BATCH-{day.strftime('%Y%m%d')}-{product_id}-{random.randint(1,9)}"
                    event_ts = day + timedelta(
                        hours=random.randint(6, 20), minutes=random.randint(0, 59)
                    )

                    failed = random.random() < rate
                    payload = {
                        "domain": "inspection",
                        "timestamp": event_ts.isoformat(),
                        "product_id": product_id,
                        "step_id": step_id,
                        "inspector_id": inspector_id,
                        "batch_id": batch_id,
                        "result": "fail" if failed else "pass",
                        "defect_code": None,
                        "severity": None,
                    }

                    defect_code = defect_desc = severity = None
                    if failed:
                        defect_code, defect_desc, severity = random.choice(DEFECT_CATALOG)
                        payload["defect_code"] = defect_code
                        payload["severity"] = severity

                    valid_shape = random.random() > 0.02
                    ingestion_id = make_bronze_record(db, SourceDomain.inspection, dict(payload), valid_shape)
                    inspection_count += 1

                    if failed and valid_shape:
                        defect_payload = {
                            "domain": "defect",
                            "timestamp": event_ts.isoformat(),
                            "product_id": product_id,
                            "defect_code": defect_code,
                            "defect_description": defect_desc,
                            "severity": severity,
                            "status": "open",
                            "root_cause": None,
                            "detected_by": inspector_id,
                        }
                        defect_valid_shape = random.random() > 0.02
                        make_bronze_record(db, SourceDomain.defect, dict(defect_payload), defect_valid_shape)
                        defect_count += 1

                        if severity in ("high", "critical") and defect_valid_shape:
                            pending_defects.append((event_ts, product_id, defect_code, severity))

        # SonarQube: one commit-quality record per day. Gate fails more
        # often during anomaly windows — engineering health and process
        # health drifting together tells a coherent demo story.
        gate_fail_chance = 0.35 if is_anomaly_day(day_index) else 0.08
        gate_failed = random.random() < gate_fail_chance
        sonarqube_payload = {
            "domain": "sonarqube",
            "timestamp": (day + timedelta(hours=23)).isoformat(),
            "commit_sha": fake.sha1()[:10],
            "blockers_count": random.randint(1, 6) if gate_failed else random.randint(0, 1),
            "code_smells_count": random.randint(5, 40),
            "security_hotspots_count": random.randint(0, 3),
            "coverage_percent": round(random.uniform(55, 70) if gate_failed else random.uniform(80, 95), 1),
            "quality_gate_status": "failed" if gate_failed else "passed",
        }
        make_bronze_record(db, SourceDomain.sonarqube, sonarqube_payload, random.random() > 0.02)

        # Resolve some pending CAPAs as we move through time (2-6 days after defect)
        still_pending = []
        for event_ts, product_id, defect_code, severity in pending_defects:
            age_days = (day - event_ts).days
            if age_days >= random.randint(2, 6):
                owner = fake.first_name() + " " + fake.last_name()[0] + "."
                opened = event_ts + timedelta(days=random.randint(1, 3))
                closed_roll = random.random()
                if closed_roll < 0.6:
                    status, closed_at, effectiveness = "closed", opened + timedelta(days=random.randint(3, 10)), random.choice(["effective", "effective", "ineffective"])
                elif closed_roll < 0.85:
                    status, closed_at, effectiveness = "in_progress", None, "pending"
                else:
                    status, closed_at, effectiveness = "overdue", None, "pending"

                capa_payload = {
                    "domain": "capa",
                    "timestamp_opened": opened.isoformat(),
                    "timestamp_closed": closed_at.isoformat() if closed_at else None,
                    "related_defect_id": None,  # resolved by normalize.py via defect_code+timestamp match
                    "defect_code": defect_code,
                    "product_id": product_id,
                    "description": f"Corrective action for {defect_code} ({severity}) on {product_id}",
                    "status": status,
                    "owner": owner,
                    "effectiveness_check": effectiveness,
                }
                make_bronze_record(db, SourceDomain.capa, capa_payload, random.random() > 0.02)
                capa_count += 1
            else:
                still_pending.append((event_ts, product_id, defect_code, severity))
        pending_defects = still_pending

        if day_index % 15 == 0:
            db.commit()

    db.commit()
    db.close()

    print("Synthetic data generation complete:")
    print(f"  Inspection records: {inspection_count}")
    print(f"  Defect records:     {defect_count}")
    print(f"  CAPA records:       {capa_count}")
    print(f"  SonarQube records:  {DAYS}")
    print(f"  Anomaly windows injected: {len(ANOMALY_WINDOWS)}")


if __name__ == "__main__":
    generate()
