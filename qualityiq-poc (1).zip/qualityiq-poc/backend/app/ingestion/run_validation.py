"""
Layer 1, step 2: validation runner.

Reads every bronze_ingestion_log row still marked 'pending', checks it
against the domain's schema (app/ingestion/validate.py), and updates
its status to 'valid' or 'invalid' with the specific errors recorded —
so a bad record's failure reason is always inspectable later, not just
silently dropped.

Run from backend/: `python -m app.ingestion.run_validation`
"""
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from app.db.session import SessionLocal
from app.db.models import BronzeIngestionLog, ValidationStatus
from app.ingestion.validate import validate_payload


def run_validation(batch_size: int = 2000):
    db = SessionLocal()
    total = valid = invalid = 0

    query = db.query(BronzeIngestionLog).filter(
        BronzeIngestionLog.validation_status == ValidationStatus.pending
    )

    while True:
        rows = query.limit(batch_size).all()
        if not rows:
            break

        for row in rows:
            payload = json.loads(row.raw_payload)
            is_valid, errors = validate_payload(row.source_domain.value, payload)
            row.validation_status = ValidationStatus.valid if is_valid else ValidationStatus.invalid
            row.validation_errors = json.dumps(errors) if errors else None
            total += 1
            valid += int(is_valid)
            invalid += int(not is_valid)

        db.commit()

    db.close()
    print("Validation complete:")
    print(f"  Total processed: {total}")
    print(f"  Valid:   {valid}")
    print(f"  Invalid: {invalid} ({round(100*invalid/total, 2) if total else 0}%)")


if __name__ == "__main__":
    run_validation()
