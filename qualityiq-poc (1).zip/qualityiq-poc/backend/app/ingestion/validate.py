"""
Validation contracts for raw payloads coming out of the Bronze layer.
Deliberately separate from app/schemas/ (API contracts) — this is what
a record must look like on arrival, not what the API returns.
"""
from datetime import datetime
from typing import Optional, Literal

from pydantic import BaseModel, ValidationError


class RawInspection(BaseModel):
    domain: Literal["inspection"]
    timestamp: datetime
    product_id: str
    step_id: str
    inspector_id: str
    batch_id: str
    result: Literal["pass", "fail"]
    defect_code: Optional[str] = None
    severity: Optional[Literal["low", "medium", "high", "critical"]] = None


class RawDefect(BaseModel):
    domain: Literal["defect"]
    timestamp: datetime
    product_id: str
    defect_code: str
    defect_description: Optional[str] = None
    severity: Literal["low", "medium", "high", "critical"]
    status: Literal["open", "investigating", "resolved"]
    root_cause: Optional[str] = None
    detected_by: str


class RawCapa(BaseModel):
    domain: Literal["capa"]
    timestamp_opened: datetime
    timestamp_closed: Optional[datetime] = None
    defect_code: str
    product_id: str
    description: str
    status: Literal["open", "in_progress", "closed", "overdue"]
    owner: str
    effectiveness_check: Literal["pending", "effective", "ineffective"]


class RawSonarqube(BaseModel):
    domain: Literal["sonarqube"]
    timestamp: datetime
    commit_sha: str
    blockers_count: int
    code_smells_count: int
    security_hotspots_count: int
    coverage_percent: float
    quality_gate_status: Literal["passed", "failed"]


DOMAIN_SCHEMAS = {
    "inspection": RawInspection,
    "defect": RawDefect,
    "capa": RawCapa,
    "sonarqube": RawSonarqube,
}


def validate_payload(domain: str, payload: dict) -> tuple[bool, list[str]]:
    """Returns (is_valid, error_messages)."""
    schema = DOMAIN_SCHEMAS.get(domain)
    if schema is None:
        return False, [f"Unknown domain: {domain}"]
    try:
        schema(**payload)
        return True, []
    except ValidationError as e:
        return False, [f"{err['loc']}: {err['msg']}" for err in e.errors()]
