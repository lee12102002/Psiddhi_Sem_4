"""
Layer 1, step 3: normalize into Silver.

Reads every bronze_ingestion_log row marked 'valid' that hasn't been
materialized yet, and inserts it into the matching fact table
(fact_inspection / fact_defect / fact_capa / fact_sonarqube). Skips
rows already materialized (checked by ingestion_id) so this is safe
to re-run.

CAPA records reference their originating defect via defect_code +
product_id + rough timestamp proximity, since the raw payload can't
know the defect's generated UUID at generation time.

Run from backend/: `python -m app.ingestion.normalize`
"""
import json
import sys
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from app.db.session import SessionLocal
from app.db.models import (
    BronzeIngestionLog, ValidationStatus, SourceDomain,
    FactInspection, FactDefect, FactCapa, FactSonarqube,
    ResultEnum, SeverityEnum, DefectStatus, CapaStatus,
    EffectivenessCheck, QualityGateStatus,
)


def already_materialized(db, model, ingestion_id: str) -> bool:
    return db.query(model.id).filter(model.ingestion_id == ingestion_id).first() is not None


def normalize():
    db = SessionLocal()
    counts = {"inspection": 0, "defect": 0, "capa": 0, "sonarqube": 0, "skipped": 0}

    valid_rows = db.query(BronzeIngestionLog).filter(
        BronzeIngestionLog.validation_status == ValidationStatus.valid
    ).order_by(BronzeIngestionLog.ingested_at).all()

    # Build a lookup of defect_id by (product_id, defect_code, rough day) for CAPA linking
    defect_lookup: dict[tuple, str] = {}

    for row in valid_rows:
        payload = json.loads(row.raw_payload)

        if row.source_domain == SourceDomain.inspection:
            if already_materialized(db, FactInspection, row.ingestion_id):
                counts["skipped"] += 1
                continue
            fact = FactInspection(
                ingestion_id=row.ingestion_id,
                event_timestamp=datetime.fromisoformat(payload["timestamp"]),
                product_id=payload["product_id"],
                step_id=payload["step_id"],
                inspector_id=payload["inspector_id"],
                batch_id=payload["batch_id"],
                result=ResultEnum.pass_ if payload["result"] == "pass" else ResultEnum.fail,
                defect_code=payload.get("defect_code"),
                severity=SeverityEnum(payload["severity"]) if payload.get("severity") else None,
            )
            db.add(fact)
            counts["inspection"] += 1

        elif row.source_domain == SourceDomain.defect:
            if already_materialized(db, FactDefect, row.ingestion_id):
                counts["skipped"] += 1
                continue
            ts = datetime.fromisoformat(payload["timestamp"])
            fact = FactDefect(
                ingestion_id=row.ingestion_id,
                event_timestamp=ts,
                product_id=payload["product_id"],
                defect_code=payload["defect_code"],
                defect_description=payload.get("defect_description"),
                severity=SeverityEnum(payload["severity"]),
                status=DefectStatus(payload["status"]),
                root_cause=payload.get("root_cause"),
                detected_by=payload["detected_by"],
            )
            db.add(fact)
            db.flush()
            defect_lookup[(payload["product_id"], payload["defect_code"], ts.date())] = fact.id
            counts["defect"] += 1

        elif row.source_domain == SourceDomain.capa:
            if already_materialized(db, FactCapa, row.ingestion_id):
                counts["skipped"] += 1
                continue
            opened = datetime.fromisoformat(payload["timestamp_opened"])
            closed = datetime.fromisoformat(payload["timestamp_closed"]) if payload.get("timestamp_closed") else None

            # Best-effort link back to the originating defect (same day-of or nearby)
            related_defect_id = defect_lookup.get((payload["product_id"], payload["defect_code"], opened.date()))
            if related_defect_id is None:
                # fall back to a fuzzy search on defect table if not in the lookup cache
                candidate = db.query(FactDefect).filter(
                    FactDefect.product_id == payload["product_id"],
                    FactDefect.defect_code == payload["defect_code"],
                ).order_by(FactDefect.event_timestamp.desc()).first()
                related_defect_id = candidate.id if candidate else None

            fact = FactCapa(
                ingestion_id=row.ingestion_id,
                related_defect_id=related_defect_id,
                timestamp_opened=opened,
                timestamp_closed=closed,
                description=payload["description"],
                status=CapaStatus(payload["status"]),
                owner=payload["owner"],
                effectiveness_check=EffectivenessCheck(payload["effectiveness_check"]),
            )
            db.add(fact)
            counts["capa"] += 1

        elif row.source_domain == SourceDomain.sonarqube:
            if already_materialized(db, FactSonarqube, row.ingestion_id):
                counts["skipped"] += 1
                continue
            fact = FactSonarqube(
                ingestion_id=row.ingestion_id,
                event_timestamp=datetime.fromisoformat(payload["timestamp"]),
                commit_sha=payload["commit_sha"],
                blockers_count=payload["blockers_count"],
                code_smells_count=payload["code_smells_count"],
                security_hotspots_count=payload["security_hotspots_count"],
                coverage_percent=payload["coverage_percent"],
                quality_gate_status=QualityGateStatus(payload["quality_gate_status"]),
            )
            db.add(fact)
            counts["sonarqube"] += 1

        if sum(counts.values()) % 2000 == 0:
            db.commit()

    db.commit()
    db.close()

    print("Normalization complete:")
    for domain, count in counts.items():
        print(f"  {domain}: {count}")


if __name__ == "__main__":
    normalize()
