"""
ORM models — the physical implementation of the schema locked in
docs/architecture.md. Layout follows the medallion pattern:

    Bronze  -> raw, immutable, append-only ingestion log
    Silver  -> validated, normalized, dimensional facts
    Gold    -> engineered features, predictions, narrations
    Auth    -> users / roles (separate concern, not part of the data lake)

Do not put API request/response shaping logic here — that belongs in
app/schemas/. This file is the source of truth for what is physically
stored, nothing more.
"""
import uuid
from datetime import datetime, timezone

from sqlalchemy import (
    Column, String, Float, Integer, Boolean, ForeignKey, DateTime, Text, Enum
)
from sqlalchemy.orm import relationship
import enum

from app.db.session import Base


def _uuid() -> str:
    return str(uuid.uuid4())


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


# ---------------------------------------------------------------------------
# BRONZE — raw ingestion log (immutable, append-only, never mutated in place)
# ---------------------------------------------------------------------------

class SourceDomain(str, enum.Enum):
    inspection = "inspection"
    defect = "defect"
    capa = "capa"
    sonarqube = "sonarqube"


class ValidationStatus(str, enum.Enum):
    pending = "pending"
    valid = "valid"
    invalid = "invalid"


class BronzeIngestionLog(Base):
    __tablename__ = "bronze_ingestion_log"

    ingestion_id = Column(String, primary_key=True, default=_uuid)
    source_domain = Column(Enum(SourceDomain), nullable=False, index=True)
    source_system = Column(String, nullable=False)  # csv_upload | rest_api | form_submit | github_webhook
    ingested_at = Column(DateTime(timezone=True), default=_utcnow, index=True)
    schema_version = Column(String, default="v1")
    raw_payload = Column(Text, nullable=False)  # JSON string, untouched original record
    validation_status = Column(Enum(ValidationStatus), default=ValidationStatus.pending, index=True)
    validation_errors = Column(Text, nullable=True)  # JSON array, nullable


# ---------------------------------------------------------------------------
# SILVER — dimension tables
# ---------------------------------------------------------------------------

class DimProduct(Base):
    __tablename__ = "dim_product"

    product_id = Column(String, primary_key=True)
    product_type = Column(String, nullable=False)
    created_at = Column(DateTime(timezone=True), default=_utcnow)


class DimProcessStep(Base):
    __tablename__ = "dim_process_step"

    step_id = Column(String, primary_key=True)
    step_name = Column(String, nullable=False)
    sequence_order = Column(Integer, nullable=False)


class DimInspector(Base):
    __tablename__ = "dim_inspector"

    inspector_id = Column(String, primary_key=True)
    name = Column(String, nullable=False)
    active = Column(Boolean, default=True)


# ---------------------------------------------------------------------------
# SILVER — fact tables (validated, normalized, unified schema)
# ---------------------------------------------------------------------------

class ResultEnum(str, enum.Enum):
    pass_ = "pass"
    fail = "fail"


class SeverityEnum(str, enum.Enum):
    low = "low"
    medium = "medium"
    high = "high"
    critical = "critical"


class FactInspection(Base):
    __tablename__ = "fact_inspection"

    id = Column(String, primary_key=True, default=_uuid)
    ingestion_id = Column(String, ForeignKey("bronze_ingestion_log.ingestion_id"), nullable=False)
    event_timestamp = Column(DateTime(timezone=True), nullable=False, index=True)
    product_id = Column(String, ForeignKey("dim_product.product_id"), nullable=False, index=True)
    step_id = Column(String, ForeignKey("dim_process_step.step_id"), nullable=False, index=True)
    inspector_id = Column(String, ForeignKey("dim_inspector.inspector_id"), nullable=False)
    batch_id = Column(String, nullable=False, index=True)
    result = Column(
        Enum(ResultEnum, values_callable=lambda enum_cls: [e.value for e in enum_cls]),
        nullable=False,
    )
    defect_code = Column(String, nullable=True)
    severity = Column(Enum(SeverityEnum), nullable=True)
    created_at = Column(DateTime(timezone=True), default=_utcnow)


class DefectStatus(str, enum.Enum):
    open = "open"
    investigating = "investigating"
    resolved = "resolved"


class FactDefect(Base):
    __tablename__ = "fact_defect"

    id = Column(String, primary_key=True, default=_uuid)
    ingestion_id = Column(String, ForeignKey("bronze_ingestion_log.ingestion_id"), nullable=False)
    event_timestamp = Column(DateTime(timezone=True), nullable=False, index=True)
    product_id = Column(String, ForeignKey("dim_product.product_id"), nullable=False, index=True)
    defect_code = Column(String, nullable=False)
    defect_description = Column(Text, nullable=True)
    severity = Column(Enum(SeverityEnum), nullable=False)
    status = Column(Enum(DefectStatus), default=DefectStatus.open, index=True)
    root_cause = Column(Text, nullable=True)
    detected_by = Column(String, nullable=False)
    created_at = Column(DateTime(timezone=True), default=_utcnow)
    updated_at = Column(DateTime(timezone=True), default=_utcnow, onupdate=_utcnow)


class CapaStatus(str, enum.Enum):
    open = "open"
    in_progress = "in_progress"
    closed = "closed"
    overdue = "overdue"


class EffectivenessCheck(str, enum.Enum):
    pending = "pending"
    effective = "effective"
    ineffective = "ineffective"


class FactCapa(Base):
    __tablename__ = "fact_capa"

    id = Column(String, primary_key=True, default=_uuid)
    ingestion_id = Column(String, ForeignKey("bronze_ingestion_log.ingestion_id"), nullable=False)
    related_defect_id = Column(String, ForeignKey("fact_defect.id"), nullable=True, index=True)
    timestamp_opened = Column(DateTime(timezone=True), nullable=False)
    timestamp_closed = Column(DateTime(timezone=True), nullable=True)
    description = Column(Text, nullable=False)
    status = Column(Enum(CapaStatus), default=CapaStatus.open, index=True)
    owner = Column(String, nullable=False)
    effectiveness_check = Column(Enum(EffectivenessCheck), default=EffectivenessCheck.pending)
    created_at = Column(DateTime(timezone=True), default=_utcnow)
    updated_at = Column(DateTime(timezone=True), default=_utcnow, onupdate=_utcnow)


class QualityGateStatus(str, enum.Enum):
    passed = "passed"
    failed = "failed"


class FactSonarqube(Base):
    __tablename__ = "fact_sonarqube"

    id = Column(String, primary_key=True, default=_uuid)
    ingestion_id = Column(String, ForeignKey("bronze_ingestion_log.ingestion_id"), nullable=False)
    event_timestamp = Column(DateTime(timezone=True), nullable=False, index=True)
    commit_sha = Column(String, nullable=False)
    blockers_count = Column(Integer, default=0)
    code_smells_count = Column(Integer, default=0)
    security_hotspots_count = Column(Integer, default=0)
    coverage_percent = Column(Float, default=0.0)
    quality_gate_status = Column(Enum(QualityGateStatus), nullable=False)
    created_at = Column(DateTime(timezone=True), default=_utcnow)


# ---------------------------------------------------------------------------
# GOLD — engineered features, predictions, narrations
# ---------------------------------------------------------------------------

class FeatureTable(Base):
    __tablename__ = "feature_table"

    id = Column(String, primary_key=True, default=_uuid)
    entity_id = Column(String, nullable=False, index=True)  # product_id or step_id
    feature_date = Column(DateTime(timezone=True), nullable=False, index=True)
    trailing_7d_defect_rate = Column(Float, nullable=False)
    trailing_30d_defect_rate = Column(Float, nullable=False)
    severity_score = Column(Float, nullable=False)
    inspector_load = Column(Float, nullable=False)
    capa_closure_rate = Column(Float, nullable=False)
    inspection_pass_rate = Column(Float, nullable=False)
    feature_set_version = Column(String, default="v1")
    computed_at = Column(DateTime(timezone=True), default=_utcnow)


class PredictionType(str, enum.Enum):
    defect_risk = "defect_risk"
    process_risk = "process_risk"
    anomaly = "anomaly"


class Prediction(Base):
    __tablename__ = "predictions"

    id = Column(String, primary_key=True, default=_uuid)
    entity_id = Column(String, nullable=False, index=True)
    prediction_type = Column(Enum(PredictionType), nullable=False, index=True)
    score = Column(Float, nullable=False)
    threshold_used = Column(Float, nullable=True)
    model_version = Column(String, nullable=False)
    generated_at = Column(DateTime(timezone=True), default=_utcnow, index=True)

    narration = relationship("Narration", back_populates="prediction", uselist=False)


class Narration(Base):
    __tablename__ = "narrations"

    id = Column(String, primary_key=True, default=_uuid)
    prediction_id = Column(String, ForeignKey("predictions.id"), nullable=False)
    narration_text = Column(Text, nullable=False)
    model_used = Column(String, nullable=False)
    prompt_version = Column(String, default="v1")
    generated_at = Column(DateTime(timezone=True), default=_utcnow)

    prediction = relationship("Prediction", back_populates="narration")


# ---------------------------------------------------------------------------
# AUTH — users / roles (simple, POC-grade, JWT-based)
# ---------------------------------------------------------------------------

class UserRole(str, enum.Enum):
    admin = "admin"
    quality_engineer = "quality_engineer"
    leadership = "leadership"


class User(Base):
    __tablename__ = "users"

    user_id = Column(String, primary_key=True, default=_uuid)
    username = Column(String, unique=True, nullable=False, index=True)
    email = Column(String, unique=True, nullable=False)
    password_hash = Column(String, nullable=False)
    role = Column(Enum(UserRole), default=UserRole.quality_engineer)
    created_at = Column(DateTime(timezone=True), default=_utcnow)
    last_login_at = Column(DateTime(timezone=True), nullable=True)
