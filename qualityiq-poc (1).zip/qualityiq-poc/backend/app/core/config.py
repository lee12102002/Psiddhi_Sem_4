"""
Central application configuration.
All values are overridable via environment variables / .env file.
Nothing downstream should hardcode a path, secret, or connection string —
everything routes through this Settings object.
"""
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    # App
    APP_NAME: str = "QualityIQ"
    ENV: str = "development"

    # Database (SQLite for POC; swap DATABASE_URL for Postgres/Azure SQL in prod)
    DATABASE_URL: str = "sqlite:///./data/qualityiq.db"

    # Auth
    JWT_SECRET_KEY: str = "CHANGE_ME_IN_PRODUCTION"
    JWT_ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60 * 8  # 8-hour session for a demo/office day

    # Data lake root (mirrors Azure Blob Storage container layout)
    DATA_ROOT: str = "../data"

    # LLM
    GEMINI_API_KEY: str = ""
    GEMINI_MODEL: str = "gemini-2.5-flash"

    # ML validation targets (from RFP minimum coverage requirements)
    DEFECT_MODEL_F1_TARGET: float = 0.80
    RISK_MODEL_CORRELATION_TARGET: float = 0.70
    ANOMALY_MODEL_PRECISION_TARGET: float = 0.85


settings = Settings()
