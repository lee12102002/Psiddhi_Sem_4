from pydantic import BaseModel, EmailStr


class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"
    role: str
    username: str


class UserOut(BaseModel):
    user_id: str
    username: str
    email: EmailStr
    role: str

    model_config = {"from_attributes": True}
