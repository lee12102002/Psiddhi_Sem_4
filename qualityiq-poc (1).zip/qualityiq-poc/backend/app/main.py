from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.core.config import settings
from app.core.logging import configure_logging
from app.api import health, auth

configure_logging()

app = FastAPI(title=settings.APP_NAME)

# POC-permissive CORS — tighten to explicit origins before any real deployment.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(health.router)
app.include_router(auth.router)

# Layer routers (inspection, defect, capa, predictions, risk, anomalies, narration)
# are added here as each is scaffolded in subsequent steps — kept out for now
# so this file stays a clean map of what's actually wired up.
