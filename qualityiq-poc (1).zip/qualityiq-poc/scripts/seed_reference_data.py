"""
Seeds the reference/dimension data every other script depends on:
  - 3 products, 4 process steps (locked scope), 5 inspectors
  - one admin user and one quality_engineer demo user for login testing

Run from backend/: `python ../scripts/seed_reference_data.py`
Safe to re-run — it's idempotent (checks before inserting).
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "backend"))

from app.db.session import SessionLocal, Base, engine
from app.db.models import DimProduct, DimProcessStep, DimInspector, User, UserRole
from app.auth.security import hash_password

Base.metadata.create_all(bind=engine)

PRODUCTS = [
    ("PROD-A", "Widget-A"),
    ("PROD-B", "Widget-B"),
    ("PROD-C", "Widget-C"),
]

STEPS = [
    ("STEP-1", "Cutting", 1),
    ("STEP-2", "Assembly", 2),
    ("STEP-3", "Finishing", 3),
    ("STEP-4", "Packaging", 4),
]

INSPECTORS = [
    ("INSP-1", "R. Menon"),
    ("INSP-2", "A. Fernandes"),
    ("INSP-3", "K. Iyer"),
    ("INSP-4", "S. Bose"),
    ("INSP-5", "T. Nair"),
]

DEMO_USERS = [
    ("admin", "admin@qualityiq.example.com", "Admin@123", UserRole.admin),
    ("engineer", "engineer@qualityiq.example.com", "Engineer@123", UserRole.quality_engineer),
    ("leadership", "leadership@qualityiq.example.com", "Leadership@123", UserRole.leadership),
]


def seed():
    db = SessionLocal()
    try:
        for pid, ptype in PRODUCTS:
            if not db.get(DimProduct, pid):
                db.add(DimProduct(product_id=pid, product_type=ptype))

        for sid, name, order in STEPS:
            if not db.get(DimProcessStep, sid):
                db.add(DimProcessStep(step_id=sid, step_name=name, sequence_order=order))

        for iid, name in INSPECTORS:
            if not db.get(DimInspector, iid):
                db.add(DimInspector(inspector_id=iid, name=name, active=True))

        for username, email, password, role in DEMO_USERS:
            existing = db.query(User).filter(User.username == username).first()
            if not existing:
                db.add(User(
                    username=username,
                    email=email,
                    password_hash=hash_password(password),
                    role=role,
                ))

        db.commit()
        print("Seed complete:")
        print(f"  Products: {len(PRODUCTS)}, Steps: {len(STEPS)}, Inspectors: {len(INSPECTORS)}")
        print("  Demo logins:")
        for username, _, password, role in DEMO_USERS:
            print(f"    {username} / {password}  (role={role.value})")
    finally:
        db.close()


if __name__ == "__main__":
    seed()
