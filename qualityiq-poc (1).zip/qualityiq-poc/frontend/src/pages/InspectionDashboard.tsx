import PageHeader from "../components/PageHeader";
import EmptyState from "../components/EmptyState";

export default function InspectionDashboard() {
  return (
    <div>
      <PageHeader
        title="Inspection Dashboard"
        subtitle="Pass rates, defect trends, and process-step throughput across the floor."
      />
      <EmptyState
        title="No inspection data yet"
        detail="This screen renders live once Layer 1 (ingestion) and Layer 2 (feature engineering) are built and the synthetic dataset is generated."
        nextStep="Next: synthetic data generator → ingestion pipeline"
      />
    </div>
  );
}
