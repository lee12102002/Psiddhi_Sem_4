import PageHeader from "../components/PageHeader";
import EmptyState from "../components/EmptyState";

export default function AiIntelligence() {
  return (
    <div>
      <PageHeader
        title="AI Defect Intelligence"
        subtitle="Model-predicted risk scores, anomaly flags, and Gemini-generated narration."
      />
      <EmptyState
        title="No model output yet"
        detail="Populated once Layer 3 (defect prediction, risk scoring, anomaly detection) is trained and Layer 4's narration endpoint is wired."
        nextStep="Next: train_defect_model.py → predictions table → narration"
      />
    </div>
  );
}
