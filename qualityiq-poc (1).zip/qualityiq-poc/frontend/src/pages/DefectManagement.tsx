import PageHeader from "../components/PageHeader";
import EmptyState from "../components/EmptyState";

export default function DefectManagement() {
  return (
    <div>
      <PageHeader
        title="Defect Management"
        subtitle="Open defects by severity, root cause, and detection source."
      />
      <EmptyState
        title="No defect records yet"
        detail="Populated from fact_defect once ingestion is live — will list, filter, and let you drill into individual defects."
        nextStep="Next: /api/defects endpoint + fact_defect data"
      />
    </div>
  );
}
