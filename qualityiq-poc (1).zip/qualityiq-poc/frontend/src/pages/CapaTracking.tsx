import PageHeader from "../components/PageHeader";
import EmptyState from "../components/EmptyState";

export default function CapaTracking() {
  return (
    <div>
      <PageHeader
        title="CAPA Tracking"
        subtitle="Corrective and preventive actions — status, ownership, and effectiveness."
      />
      <EmptyState
        title="No CAPA records yet"
        detail="Populated from fact_capa, linked to fact_defect via related_defect_id."
        nextStep="Next: /api/capa endpoint + fact_capa data"
      />
    </div>
  );
}
