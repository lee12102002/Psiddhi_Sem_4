import { useState, type FormEvent } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

export default function Login() {
  const { login, error } = useAuth();
  const navigate = useNavigate();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [submitting, setSubmitting] = useState(false);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setSubmitting(true);
    try {
      await login(username, password);
      navigate("/", { replace: true });
    } catch {
      // error is already surfaced via auth context state
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-graphite px-4">
      <div className="w-full max-w-sm">
        {/* Signature strip - three status lights, echoes the app shell's gate strip */}
        <div className="flex items-center gap-1.5 mb-6">
          <span className="indicator-light bg-gauge-green" />
          <span className="indicator-light bg-amber" />
          <span className="indicator-light bg-hairline" />
        </div>

        <h1 className="font-mono-panel text-2xl tracking-tight text-text-primary mb-1">
          QualityIQ
        </h1>
        <p className="panel-label mb-8">Quality Intelligence Console</p>

        <form onSubmit={handleSubmit} className="bg-panel border border-hairline rounded-sm p-6 space-y-5">
          <div>
            <label htmlFor="username" className="panel-label block mb-2">
              Operator ID
            </label>
            <input
              id="username"
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              required
              autoFocus
              autoComplete="username"
              className="w-full bg-graphite border border-hairline rounded-sm px-3 py-2.5
                         text-text-primary font-sans-body
                         focus-visible:border-amber"
            />
          </div>

          <div>
            <label htmlFor="password" className="panel-label block mb-2">
              Passcode
            </label>
            <input
              id="password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              autoComplete="current-password"
              className="w-full bg-graphite border border-hairline rounded-sm px-3 py-2.5
                         text-text-primary font-sans-body
                         focus-visible:border-amber"
            />
          </div>

          {error && (
            <div className="flex items-center gap-2 text-sm text-alarm-red">
              <span className="indicator-light bg-alarm-red" />
              {error}
            </div>
          )}

          <button
            type="submit"
            disabled={submitting}
            className="w-full bg-amber text-graphite font-medium rounded-sm py-2.5
                       hover:bg-amber-dim hover:text-text-primary transition-colors
                       disabled:opacity-50"
          >
            {submitting ? "Authenticating…" : "Enter console"}
          </button>
        </form>

        <p className="panel-label mt-6 text-center text-text-faint">
          Demo access — admin / Admin@123 · engineer / Engineer@123 · leadership / Leadership@123
        </p>
      </div>
    </div>
  );
}
