export default function PageHeader({ title, subtitle }: { title: string; subtitle: string }) {
  return (
    <div className="mb-8">
      <h2 className="font-mono-panel text-xl text-text-primary mb-1">{title}</h2>
      <p className="text-sm text-text-muted">{subtitle}</p>
    </div>
  );
}
