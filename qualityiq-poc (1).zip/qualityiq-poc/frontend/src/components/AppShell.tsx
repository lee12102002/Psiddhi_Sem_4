import type { ReactNode } from "react";
import { NavLink } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import GateStrip from "./GateStrip";

const NAV_ITEMS = [
  { to: "/", label: "Inspection Dashboard", end: true },
  { to: "/defects", label: "Defect Management" },
  { to: "/capa", label: "CAPA Tracking" },
  { to: "/ai-intelligence", label: "AI Defect Intelligence" },
];

export default function AppShell({ children }: { children: ReactNode }) {
  const { user, logout } = useAuth();

  return (
    <div className="min-h-screen flex bg-graphite">
      <aside className="w-60 shrink-0 border-r border-hairline flex flex-col">
        <div className="px-5 py-5 border-b border-hairline">
          <div className="flex items-center gap-1.5 mb-2">
            <span className="indicator-light bg-gauge-green" />
            <span className="indicator-light bg-amber" />
            <span className="indicator-light bg-hairline" />
          </div>
          <h1 className="font-mono-panel text-lg text-text-primary">QualityIQ</h1>
        </div>

        <nav className="flex-1 px-3 py-4 space-y-1">
          {NAV_ITEMS.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.end}
              className={({ isActive }) =>
                `block px-3 py-2 rounded-sm text-sm transition-colors ${
                  isActive
                    ? "bg-panel-raised text-text-primary border-l-2 border-amber"
                    : "text-text-muted hover:bg-panel hover:text-text-primary border-l-2 border-transparent"
                }`
              }
            >
              {item.label}
            </NavLink>
          ))}
        </nav>

        <div className="px-5 py-4 border-t border-hairline">
          <p className="panel-label mb-1">{user?.role.replace("_", " ")}</p>
          <p className="text-sm text-text-primary mb-3">{user?.username}</p>
          <button
            onClick={logout}
            className="panel-label text-text-faint hover:text-alarm-red transition-colors"
          >
            Sign out
          </button>
        </div>
      </aside>

      <div className="flex-1 flex flex-col min-w-0">
        <GateStrip />
        <main className="flex-1 p-8 overflow-auto">{children}</main>
      </div>
    </div>
  );
}
