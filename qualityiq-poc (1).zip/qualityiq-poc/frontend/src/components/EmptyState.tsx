interface EmptyStateProps {
  title: string;
  detail: string;
  nextStep: string;
}

export default function EmptyState({ title, detail, nextStep }: EmptyStateProps) {
  return (
    <div className="border border-dashed border-hairline rounded-sm p-10 text-center max-w-lg mx-auto mt-16">
      <div className="flex justify-center mb-4">
        <span className="indicator-light bg-standby" />
      </div>
      <h3 className="text-text-primary font-medium mb-2">{title}</h3>
      <p className="text-sm text-text-muted mb-4">{detail}</p>
      <p className="panel-label text-text-faint">{nextStep}</p>
    </div>
  );
}
