interface Gate {
  label: string;
  status: "passed" | "failed" | "pending";
}

// Static placeholder values — wired to real GitHub Actions / SonarQube
// results once Layer 5 (CI/CD gates) is built. Kept visible now because
// the always-on gate strip is the product's core thesis: quality is
// enforced continuously, not reviewed after the fact.
const GATES: Gate[] = [
  { label: "Test coverage \u2265 80%", status: "pending" },
  { label: "SonarQube quality gate", status: "pending" },
  { label: "Prediction threshold", status: "pending" },
];

const statusColor: Record<Gate["status"], string> = {
  passed: "bg-gauge-green",
  failed: "bg-alarm-red",
  pending: "bg-standby",
};

export default function GateStrip() {
  return (
    <div className="flex items-center gap-6 px-6 py-2 bg-panel border-b border-hairline">
      <span className="panel-label text-text-faint">Quality gates</span>
      {GATES.map((gate) => (
        <div key={gate.label} className="flex items-center gap-2">
          <span className={`indicator-light ${statusColor[gate.status]}`} />
          <span className="panel-label normal-case tracking-normal text-text-muted">
            {gate.label}
          </span>
        </div>
      ))}
    </div>
  );
}
