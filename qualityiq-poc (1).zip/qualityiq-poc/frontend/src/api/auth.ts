import { apiGet, apiPostForm } from "./client";

export type UserRole = "admin" | "quality_engineer" | "leadership";

export interface TokenResponse {
  access_token: string;
  token_type: string;
  role: UserRole;
  username: string;
}

export interface CurrentUser {
  user_id: string;
  username: string;
  email: string;
  role: UserRole;
}

export function login(username: string, password: string): Promise<TokenResponse> {
  return apiPostForm<TokenResponse>("/api/auth/login", { username, password });
}

export function getCurrentUser(): Promise<CurrentUser> {
  return apiGet<CurrentUser>("/api/auth/me");
}
