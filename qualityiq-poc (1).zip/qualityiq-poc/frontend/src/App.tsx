import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AuthProvider } from "./context/AuthContext";
import ProtectedRoute from "./components/ProtectedRoute";
import AppShell from "./components/AppShell";
import Login from "./pages/Login";
import InspectionDashboard from "./pages/InspectionDashboard";
import DefectManagement from "./pages/DefectManagement";
import CapaTracking from "./pages/CapaTracking";
import AiIntelligence from "./pages/AiIntelligence";

function Protected({ children }: { children: React.ReactNode }) {
  return (
    <ProtectedRoute>
      <AppShell>{children}</AppShell>
    </ProtectedRoute>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/" element={<Protected><InspectionDashboard /></Protected>} />
          <Route path="/defects" element={<Protected><DefectManagement /></Protected>} />
          <Route path="/capa" element={<Protected><CapaTracking /></Protected>} />
          <Route path="/ai-intelligence" element={<Protected><AiIntelligence /></Protected>} />
        </Routes>
      </AuthProvider>
    </BrowserRouter>
  );
}
