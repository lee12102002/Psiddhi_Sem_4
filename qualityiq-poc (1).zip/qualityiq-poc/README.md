# QualityIQ — POC

A working slice of the QualityIQ 5-layer quality management platform:
unified data schema, JWT-authenticated API, and a React console — proven
end-to-end, not mocked.

## What's built in this pass

- **Schema** — medallion architecture (Bronze/Silver/Gold) with 12 tables,
  migrated via Alembic and tested (`backend/app/db/models.py`)
- **Auth** — JWT login, 3 roles (admin / quality_engineer / leadership),
  7 passing tests (`backend/tests/unit/test_auth.py`)
- **Reference data** — 3 products, 4 process steps, 5 inspectors, seeded
  and demo-loginable
- **Frontend shell** — instrument-panel design system, login flow wired to
  the real backend, protected routing, sidebar nav, and 4 page stubs with
  honest empty states (no fake data)

## What's not built yet (see conversation for the full roadmap)

Synthetic data generator, ingestion pipeline, feature engineering, ML
model training, prediction/narration endpoints, CI/CD quality gates,
reporting dashboard. The gate strip and page stubs are wired to show
these the moment they exist — no frontend rework needed.

## Running it

### Backend

```bash
cd backend
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
alembic upgrade head
python3 ../scripts/seed_reference_data.py
uvicorn app.main:app --reload --port 8000
```

### Frontend

```bash
cd frontend
npm install
npm run dev
```

Open http://localhost:5173. Demo logins:

| Username     | Password         | Role             |
|--------------|------------------|------------------|
| admin        | Admin@123        | admin            |
| engineer     | Engineer@123     | quality_engineer |
| leadership   | Leadership@123   | leadership       |

### Tests

```bash
cd backend
python3 -m pytest tests/ -v --cov=app
```

## Project layout

See `docs/architecture.md` for the full schema reference and the repo
structure diagram covered during planning.
