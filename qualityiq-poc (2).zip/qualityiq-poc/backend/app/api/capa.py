from typing import Optional

from fastapi import APIRouter, Depends, Query
from sqlalchemy import func
from sqlalchemy.orm import Session

from app.db.session import get_db
from app.db.models import FactCapa, FactDefect, CapaStatus
from app.schemas.capa import CapaSummary, CapaStatusCount, PaginatedCapa, CapaOut
from app.auth.dependencies import get_current_user

router = APIRouter(prefix="/api/capa", tags=["capa"])


@router.get("/summary", response_model=CapaSummary)
def get_summary(db: Session = Depends(get_db), _=Depends(get_current_user)):
    total = db.query(func.count(FactCapa.id)).scalar() or 0

    by_status_rows = (
        db.query(FactCapa.status, func.count(FactCapa.id)).group_by(FactCapa.status).all()
    )

    avg_days = db.query(
        func.avg(func.julianday(FactCapa.timestamp_closed) - func.julianday(FactCapa.timestamp_opened))
    ).filter(FactCapa.status == CapaStatus.closed).scalar()

    return CapaSummary(
        total=total,
        by_status=[CapaStatusCount(status=s.value, count=c) for s, c in by_status_rows],
        avg_days_to_close=round(avg_days, 1) if avg_days is not None else None,
    )


@router.get("", response_model=PaginatedCapa)
def list_capa(
    status: Optional[str] = None,
    page: int = Query(1, ge=1),
    page_size: int = Query(25, ge=1, le=100),
    db: Session = Depends(get_db),
    _=Depends(get_current_user),
):
    query = (
        db.query(
            FactCapa.id, FactCapa.timestamp_opened, FactCapa.timestamp_closed,
            FactCapa.description, FactCapa.status, FactCapa.owner,
            FactCapa.effectiveness_check, FactDefect.defect_code,
        )
        .outerjoin(FactDefect, FactCapa.related_defect_id == FactDefect.id)
    )
    if status:
        query = query.filter(FactCapa.status == status)

    total = query.count()
    rows = (
        query.order_by(FactCapa.timestamp_opened.desc())
        .offset((page - 1) * page_size)
        .limit(page_size)
        .all()
    )

    items = [
        CapaOut(
            id=r.id, timestamp_opened=r.timestamp_opened, timestamp_closed=r.timestamp_closed,
            description=r.description, status=r.status.value, owner=r.owner,
            effectiveness_check=r.effectiveness_check.value, related_defect_code=r.defect_code,
        )
        for r in rows
    ]

    return PaginatedCapa(items=items, page=page, page_size=page_size, total=total)
