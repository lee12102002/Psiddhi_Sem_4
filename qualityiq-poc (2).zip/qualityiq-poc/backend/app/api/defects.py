from typing import Optional

from fastapi import APIRouter, Depends, Query
from sqlalchemy import func
from sqlalchemy.orm import Session

from app.db.session import get_db
from app.db.models import FactDefect, DimProduct
from app.schemas.defect import DefectSummary, SeverityCount, StatusCount, PaginatedDefects, DefectOut
from app.auth.dependencies import get_current_user

router = APIRouter(prefix="/api/defects", tags=["defects"])


@router.get("/summary", response_model=DefectSummary)
def get_summary(db: Session = Depends(get_db), _=Depends(get_current_user)):
    total = db.query(func.count(FactDefect.id)).scalar() or 0

    by_severity_rows = (
        db.query(FactDefect.severity, func.count(FactDefect.id))
        .group_by(FactDefect.severity).all()
    )
    by_status_rows = (
        db.query(FactDefect.status, func.count(FactDefect.id))
        .group_by(FactDefect.status).all()
    )

    return DefectSummary(
        total=total,
        by_severity=[SeverityCount(severity=s.value, count=c) for s, c in by_severity_rows],
        by_status=[StatusCount(status=s.value, count=c) for s, c in by_status_rows],
    )


@router.get("", response_model=PaginatedDefects)
def list_defects(
    severity: Optional[str] = None,
    status: Optional[str] = None,
    page: int = Query(1, ge=1),
    page_size: int = Query(25, ge=1, le=100),
    db: Session = Depends(get_db),
    _=Depends(get_current_user),
):
    query = (
        db.query(
            FactDefect.id, FactDefect.event_timestamp, FactDefect.product_id,
            DimProduct.product_type, FactDefect.defect_code, FactDefect.defect_description,
            FactDefect.severity, FactDefect.status, FactDefect.detected_by,
        )
        .join(DimProduct, FactDefect.product_id == DimProduct.product_id)
    )
    if severity:
        query = query.filter(FactDefect.severity == severity)
    if status:
        query = query.filter(FactDefect.status == status)

    total = query.count()
    rows = (
        query.order_by(FactDefect.event_timestamp.desc())
        .offset((page - 1) * page_size)
        .limit(page_size)
        .all()
    )

    items = [
        DefectOut(
            id=r.id, event_timestamp=r.event_timestamp, product_id=r.product_id,
            product_type=r.product_type, defect_code=r.defect_code,
            defect_description=r.defect_description, severity=r.severity.value,
            status=r.status.value, detected_by=r.detected_by,
        )
        for r in rows
    ]

    return PaginatedDefects(items=items, page=page, page_size=page_size, total=total)
