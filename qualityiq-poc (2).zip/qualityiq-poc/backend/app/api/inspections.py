from datetime import date, timedelta

from fastapi import APIRouter, Depends
from sqlalchemy import func, case
from sqlalchemy.orm import Session

from app.db.session import get_db
from app.db.models import (
    FactInspection, FactDefect, FactCapa, DimProduct, DimProcessStep,
    ResultEnum, CapaStatus,
)
from app.schemas.inspection import (
    InspectionKpis, DailyTrendPoint, ProductStepDefectRate, InspectionDashboardResponse,
)
from app.auth.dependencies import get_current_user

router = APIRouter(prefix="/api/inspections", tags=["inspections"])


@router.get("/dashboard", response_model=InspectionDashboardResponse)
def get_dashboard(db: Session = Depends(get_db), _=Depends(get_current_user)):
    total_inspections = db.query(func.count(FactInspection.id)).scalar() or 0
    total_fails = db.query(func.count(FactInspection.id)).filter(
        FactInspection.result == ResultEnum.fail
    ).scalar() or 0
    total_defects = db.query(func.count(FactDefect.id)).scalar() or 0
    open_capas = db.query(func.count(FactCapa.id)).filter(
        FactCapa.status.in_([CapaStatus.open, CapaStatus.in_progress, CapaStatus.overdue])
    ).scalar() or 0

    date_bounds = db.query(
        func.min(FactInspection.event_timestamp), func.max(FactInspection.event_timestamp)
    ).first()
    range_start = date_bounds[0].date() if date_bounds and date_bounds[0] else date.today()
    range_end = date_bounds[1].date() if date_bounds and date_bounds[1] else date.today()

    pass_rate = round(100 * (total_inspections - total_fails) / total_inspections, 2) if total_inspections else 0.0

    kpis = InspectionKpis(
        total_inspections=total_inspections,
        pass_rate=pass_rate,
        total_defects=total_defects,
        open_capas=open_capas,
        date_range_start=range_start,
        date_range_end=range_end,
    )

    # Daily trend — SQLite date() function truncates the timestamp to a day bucket.
    day_col = func.date(FactInspection.event_timestamp).label("day")
    trend_rows = (
        db.query(
            day_col,
            func.count(FactInspection.id).label("total"),
            func.sum(case((FactInspection.result == ResultEnum.fail, 1), else_=0)).label("fails"),
        )
        .group_by(day_col)
        .order_by(day_col)
        .all()
    )
    daily_trend = [
        DailyTrendPoint(
            date=row.day,
            total=row.total,
            fails=row.fails or 0,
            defect_rate=round(100 * (row.fails or 0) / row.total, 2) if row.total else 0.0,
        )
        for row in trend_rows
    ]

    # Defect rate by product x step
    breakdown_rows = (
        db.query(
            DimProduct.product_id,
            DimProduct.product_type,
            DimProcessStep.step_id,
            DimProcessStep.step_name,
            func.count(FactInspection.id).label("total"),
            func.sum(case((FactInspection.result == ResultEnum.fail, 1), else_=0)).label("fails"),
        )
        .join(FactInspection, FactInspection.product_id == DimProduct.product_id)
        .join(DimProcessStep, FactInspection.step_id == DimProcessStep.step_id)
        .group_by(DimProduct.product_id, DimProcessStep.step_id)
        .order_by(DimProduct.product_id, DimProcessStep.sequence_order)
        .all()
    )
    breakdown = [
        ProductStepDefectRate(
            product_id=row.product_id,
            product_type=row.product_type,
            step_id=row.step_id,
            step_name=row.step_name,
            total=row.total,
            fails=row.fails or 0,
            defect_rate=round(100 * (row.fails or 0) / row.total, 2) if row.total else 0.0,
        )
        for row in breakdown_rows
    ]

    return InspectionDashboardResponse(
        kpis=kpis, daily_trend=daily_trend, defect_rate_by_product_step=breakdown
    )
