from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.core.config import settings
from app.core.logging import configure_logging
from app.api import health, auth, inspections, defects, capa

configure_logging()

app = FastAPI(title=settings.APP_NAME)

# POC-permissive CORS — tighten to explicit origins before any real deployment.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(health.router)
app.include_router(auth.router)
app.include_router(inspections.router)
app.include_router(defects.router)
app.include_router(capa.router)

# Remaining layer routers (predictions, risk, anomalies, narration) are
# added here once Layer 3 (ML) and Layer 4 (LLM narration) exist.
