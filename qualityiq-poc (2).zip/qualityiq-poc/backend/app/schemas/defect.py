from datetime import datetime
from typing import Optional
from pydantic import BaseModel


class DefectOut(BaseModel):
    id: str
    event_timestamp: datetime
    product_id: str
    product_type: str
    defect_code: str
    defect_description: Optional[str]
    severity: str
    status: str
    detected_by: str

    model_config = {"from_attributes": True}


class SeverityCount(BaseModel):
    severity: str
    count: int


class StatusCount(BaseModel):
    status: str
    count: int


class DefectSummary(BaseModel):
    by_severity: list[SeverityCount]
    by_status: list[StatusCount]
    total: int


class PaginatedDefects(BaseModel):
    items: list[DefectOut]
    page: int
    page_size: int
    total: int
