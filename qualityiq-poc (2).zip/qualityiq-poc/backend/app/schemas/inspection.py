from datetime import date
from typing import Optional
from pydantic import BaseModel


class InspectionKpis(BaseModel):
    total_inspections: int
    pass_rate: float
    total_defects: int
    open_capas: int
    date_range_start: date
    date_range_end: date


class DailyTrendPoint(BaseModel):
    date: date
    total: int
    fails: int
    defect_rate: float


class ProductStepDefectRate(BaseModel):
    product_id: str
    product_type: str
    step_id: str
    step_name: str
    total: int
    fails: int
    defect_rate: float


class InspectionDashboardResponse(BaseModel):
    kpis: InspectionKpis
    daily_trend: list[DailyTrendPoint]
    defect_rate_by_product_step: list[ProductStepDefectRate]
