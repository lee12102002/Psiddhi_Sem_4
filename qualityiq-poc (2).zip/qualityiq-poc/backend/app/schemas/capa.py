from datetime import datetime
from typing import Optional
from pydantic import BaseModel


class CapaOut(BaseModel):
    id: str
    timestamp_opened: datetime
    timestamp_closed: Optional[datetime]
    description: str
    status: str
    owner: str
    effectiveness_check: str
    related_defect_code: Optional[str] = None

    model_config = {"from_attributes": True}


class CapaStatusCount(BaseModel):
    status: str
    count: int


class CapaSummary(BaseModel):
    total: int
    by_status: list[CapaStatusCount]
    avg_days_to_close: Optional[float]


class PaginatedCapa(BaseModel):
    items: list[CapaOut]
    page: int
    page_size: int
    total: int
