"""
conftest.py runs before pytest collects/imports any test module, so setting
the test DATABASE_URL here (rather than inside individual test files)
guarantees every test file shares the same engine pointed at the same
throwaway database — avoiding the module-caching trap where the second
test file's os.environ override is silently ignored because app.core.config
was already imported (and its Settings singleton already built) by the
first test file.
"""
import os
import sys
from pathlib import Path

os.environ["DATABASE_URL"] = "sqlite:///./test_qualityiq_shared.db"

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import pytest


@pytest.fixture(scope="session", autouse=True)
def cleanup_test_db():
    yield
    db_path = Path("test_qualityiq_shared.db")
    if db_path.exists():
        db_path.unlink()
