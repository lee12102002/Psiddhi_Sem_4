"""
Tests for the data endpoints built on top of Layer 1 output.
Seeds a small, deterministic set of fact rows directly (not via the full
90-day generator) so this suite runs fast and its assertions are exact.
"""
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import pytest
from fastapi.testclient import TestClient

from app.main import app
from app.db.session import Base, engine, SessionLocal
from app.db.models import (
    User, UserRole, DimProduct, DimProcessStep, DimInspector,
    BronzeIngestionLog, SourceDomain, ValidationStatus,
    FactInspection, FactDefect, FactCapa,
    ResultEnum, SeverityEnum, DefectStatus, CapaStatus, EffectivenessCheck,
)
from app.auth.security import hash_password

client = TestClient(app)


@pytest.fixture(scope="module", autouse=True)
def seed_fixture_data():
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()

    db.add(User(username="fixtureuser", email="fixture@example.com",
                 password_hash=hash_password("Fixture@123"), role=UserRole.quality_engineer))
    db.add(DimProduct(product_id="P1", product_type="Widget-Test"))
    db.add(DimProcessStep(step_id="S1", step_name="Cutting", sequence_order=1))
    db.add(DimInspector(inspector_id="I1", name="Test Inspector"))
    db.commit()

    now = datetime.now(timezone.utc)

    # 10 inspections: 8 pass, 2 fail
    for i in range(10):
        bronze = BronzeIngestionLog(
            source_domain=SourceDomain.inspection, source_system="test",
            raw_payload="{}", validation_status=ValidationStatus.valid,
        )
        db.add(bronze)
        db.flush()
        db.add(FactInspection(
            ingestion_id=bronze.ingestion_id,
            event_timestamp=now - timedelta(days=i),
            product_id="P1", step_id="S1", inspector_id="I1",
            batch_id=f"B{i}",
            result=ResultEnum.fail if i < 2 else ResultEnum.pass_,
            severity=SeverityEnum.high if i < 2 else None,
        ))

    # 2 defects, one linked to a CAPA
    bronze_d1 = BronzeIngestionLog(source_domain=SourceDomain.defect, source_system="test",
                                     raw_payload="{}", validation_status=ValidationStatus.valid)
    db.add(bronze_d1)
    db.flush()
    defect1 = FactDefect(
        ingestion_id=bronze_d1.ingestion_id, event_timestamp=now,
        product_id="P1", defect_code="DEF-X", defect_description="Test defect",
        severity=SeverityEnum.critical, status=DefectStatus.open, detected_by="I1",
    )
    db.add(defect1)
    db.flush()

    bronze_c1 = BronzeIngestionLog(source_domain=SourceDomain.capa, source_system="test",
                                     raw_payload="{}", validation_status=ValidationStatus.valid)
    db.add(bronze_c1)
    db.flush()
    db.add(FactCapa(
        ingestion_id=bronze_c1.ingestion_id, related_defect_id=defect1.id,
        timestamp_opened=now, timestamp_closed=None,
        description="Fix it", status=CapaStatus.open, owner="Tester",
        effectiveness_check=EffectivenessCheck.pending,
    ))

    db.commit()
    db.close()
    yield
    # Cleanup of the shared test DB file happens once, session-wide, in conftest.py.


def auth_headers():
    resp = client.post("/api/auth/login", data={"username": "fixtureuser", "password": "Fixture@123"})
    token = resp.json()["access_token"]
    return {"Authorization": f"Bearer {token}"}


def test_dashboard_requires_auth():
    resp = client.get("/api/inspections/dashboard")
    assert resp.status_code == 401


def test_dashboard_kpis_correct():
    resp = client.get("/api/inspections/dashboard", headers=auth_headers())
    assert resp.status_code == 200
    body = resp.json()
    assert body["kpis"]["total_inspections"] == 10
    assert body["kpis"]["pass_rate"] == 80.0  # 8/10 pass


def test_defects_summary():
    resp = client.get("/api/defects/summary", headers=auth_headers())
    assert resp.status_code == 200
    body = resp.json()
    assert body["total"] == 1
    assert body["by_severity"][0]["severity"] == "critical"


def test_defects_list_filter_by_severity():
    resp = client.get("/api/defects?severity=critical", headers=auth_headers())
    assert resp.status_code == 200
    assert resp.json()["total"] == 1

    resp2 = client.get("/api/defects?severity=low", headers=auth_headers())
    assert resp2.json()["total"] == 0


def test_capa_summary_and_linkage():
    resp = client.get("/api/capa/summary", headers=auth_headers())
    assert resp.status_code == 200
    assert resp.json()["total"] == 1

    resp2 = client.get("/api/capa", headers=auth_headers())
    item = resp2.json()["items"][0]
    assert item["related_defect_code"] == "DEF-X"
