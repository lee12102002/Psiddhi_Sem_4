interface KpiCardProps {
  label: string;
  value: string | number;
  tone?: "neutral" | "good" | "bad";
}

const toneColor: Record<NonNullable<KpiCardProps["tone"]>, string> = {
  neutral: "text-text-primary",
  good: "text-gauge-green",
  bad: "text-alarm-red",
};

export default function KpiCard({ label, value, tone = "neutral" }: KpiCardProps) {
  return (
    <div className="bg-panel border border-hairline rounded-sm p-4">
      <p className="panel-label mb-2">{label}</p>
      <p className={`data-figure text-2xl ${toneColor[tone]}`}>{value}</p>
    </div>
  );
}
