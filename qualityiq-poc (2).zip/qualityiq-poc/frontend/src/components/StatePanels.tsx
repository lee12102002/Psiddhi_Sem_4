export function LoadingPanel() {
  return (
    <div className="flex items-center gap-2 text-text-muted panel-label py-10 justify-center">
      <span className="indicator-light bg-amber animate-pulse" />
      Loading live data…
    </div>
  );
}

export function ErrorPanel({ message }: { message: string }) {
  return (
    <div className="flex items-center gap-2 text-alarm-red text-sm border border-alarm-red/30 bg-alarm-red/10 rounded-sm px-4 py-3">
      <span className="indicator-light bg-alarm-red" />
      {message}
    </div>
  );
}
