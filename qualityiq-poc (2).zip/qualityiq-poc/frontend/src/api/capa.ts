import { apiGet } from "./client";

export interface CapaOut {
  id: string;
  timestamp_opened: string;
  timestamp_closed: string | null;
  description: string;
  status: "open" | "in_progress" | "closed" | "overdue";
  owner: string;
  effectiveness_check: "pending" | "effective" | "ineffective";
  related_defect_code: string | null;
}

export interface CapaStatusCount {
  status: string;
  count: number;
}

export interface CapaSummary {
  total: number;
  by_status: CapaStatusCount[];
  avg_days_to_close: number | null;
}

export interface PaginatedCapa {
  items: CapaOut[];
  page: number;
  page_size: number;
  total: number;
}

export function getCapaSummary(): Promise<CapaSummary> {
  return apiGet<CapaSummary>("/api/capa/summary");
}

export function listCapa(params: { status?: string; page?: number; page_size?: number }): Promise<PaginatedCapa> {
  const qs = new URLSearchParams();
  if (params.status) qs.set("status", params.status);
  qs.set("page", String(params.page ?? 1));
  qs.set("page_size", String(params.page_size ?? 25));
  return apiGet<PaginatedCapa>(`/api/capa?${qs.toString()}`);
}
