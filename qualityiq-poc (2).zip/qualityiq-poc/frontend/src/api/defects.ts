import { apiGet } from "./client";

export interface DefectOut {
  id: string;
  event_timestamp: string;
  product_id: string;
  product_type: string;
  defect_code: string;
  defect_description: string | null;
  severity: "low" | "medium" | "high" | "critical";
  status: "open" | "investigating" | "resolved";
  detected_by: string;
}

export interface SeverityCount {
  severity: string;
  count: number;
}

export interface StatusCount {
  status: string;
  count: number;
}

export interface DefectSummary {
  by_severity: SeverityCount[];
  by_status: StatusCount[];
  total: number;
}

export interface PaginatedDefects {
  items: DefectOut[];
  page: number;
  page_size: number;
  total: number;
}

export function getDefectSummary(): Promise<DefectSummary> {
  return apiGet<DefectSummary>("/api/defects/summary");
}

export function listDefects(params: {
  severity?: string;
  status?: string;
  page?: number;
  page_size?: number;
}): Promise<PaginatedDefects> {
  const qs = new URLSearchParams();
  if (params.severity) qs.set("severity", params.severity);
  if (params.status) qs.set("status", params.status);
  qs.set("page", String(params.page ?? 1));
  qs.set("page_size", String(params.page_size ?? 25));
  return apiGet<PaginatedDefects>(`/api/defects?${qs.toString()}`);
}
