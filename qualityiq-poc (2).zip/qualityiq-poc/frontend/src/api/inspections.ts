import { apiGet } from "./client";

export interface InspectionKpis {
  total_inspections: number;
  pass_rate: number;
  total_defects: number;
  open_capas: number;
  date_range_start: string;
  date_range_end: string;
}

export interface DailyTrendPoint {
  date: string;
  total: number;
  fails: number;
  defect_rate: number;
}

export interface ProductStepDefectRate {
  product_id: string;
  product_type: string;
  step_id: string;
  step_name: string;
  total: number;
  fails: number;
  defect_rate: number;
}

export interface InspectionDashboard {
  kpis: InspectionKpis;
  daily_trend: DailyTrendPoint[];
  defect_rate_by_product_step: ProductStepDefectRate[];
}

export function getInspectionDashboard(): Promise<InspectionDashboard> {
  return apiGet<InspectionDashboard>("/api/inspections/dashboard");
}
