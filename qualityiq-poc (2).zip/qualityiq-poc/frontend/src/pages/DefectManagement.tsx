import { useState } from "react";
import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer, Legend } from "recharts";
import PageHeader from "../components/PageHeader";
import { LoadingPanel, ErrorPanel } from "../components/StatePanels";
import { useApiData } from "../api/useApiData";
import { getDefectSummary, listDefects } from "../api/defects";

const SEVERITY_COLOR: Record<string, string> = {
  low: "#5B6472",
  medium: "#E8A33D",
  high: "#D6883A",
  critical: "#D65B4A",
};

export default function DefectManagement() {
  const [severityFilter, setSeverityFilter] = useState<string | undefined>(undefined);
  const [page, setPage] = useState(1);

  const summary = useApiData(getDefectSummary);
  const list = useApiData(
    () => listDefects({ severity: severityFilter, page, page_size: 15 }),
    [severityFilter, page]
  );

  return (
    <div>
      <PageHeader
        title="Defect Management"
        subtitle="Open defects by severity, root cause, and detection source."
      />

      {summary.isLoading && <LoadingPanel />}
      {summary.error && <ErrorPanel message={summary.error} />}

      {summary.data && (
        <div className="grid grid-cols-3 gap-6 mb-8">
          <div className="bg-panel border border-hairline rounded-sm p-5 col-span-1">
            <p className="panel-label mb-4">Defects by severity</p>
            <ResponsiveContainer width="100%" height={220}>
              <PieChart>
                <Pie
                  data={summary.data.by_severity}
                  dataKey="count"
                  nameKey="severity"
                  innerRadius={40}
                  outerRadius={80}
                  paddingAngle={2}
                >
                  {summary.data.by_severity.map((entry) => (
                    <Cell key={entry.severity} fill={SEVERITY_COLOR[entry.severity] ?? "#5B6472"} />
                  ))}
                </Pie>
                <Tooltip contentStyle={{ background: "#242A32", border: "1px solid #3A424C", fontSize: 12 }} />
                <Legend wrapperStyle={{ fontSize: 11, color: "#8A9199" }} />
              </PieChart>
            </ResponsiveContainer>
          </div>

          <div className="bg-panel border border-hairline rounded-sm p-5 col-span-2 flex flex-col justify-center">
            <p className="panel-label mb-3">Filter by severity</p>
            <div className="flex gap-2 flex-wrap">
              <button
                onClick={() => { setSeverityFilter(undefined); setPage(1); }}
                className={`px-3 py-1.5 rounded-sm text-sm border ${
                  !severityFilter ? "border-amber text-amber" : "border-hairline text-text-muted"
                }`}
              >
                All ({summary.data.total})
              </button>
              {summary.data.by_severity.map((s) => (
                <button
                  key={s.severity}
                  onClick={() => { setSeverityFilter(s.severity); setPage(1); }}
                  className={`px-3 py-1.5 rounded-sm text-sm border capitalize ${
                    severityFilter === s.severity ? "border-amber text-amber" : "border-hairline text-text-muted"
                  }`}
                >
                  {s.severity} ({s.count})
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {list.isLoading && <LoadingPanel />}
      {list.error && <ErrorPanel message={list.error} />}

      {list.data && (
        <div className="bg-panel border border-hairline rounded-sm overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="panel-label border-b border-hairline">
                <th className="text-left px-4 py-3">Defect</th>
                <th className="text-left px-4 py-3">Product</th>
                <th className="text-left px-4 py-3">Severity</th>
                <th className="text-left px-4 py-3">Status</th>
                <th className="text-left px-4 py-3">Detected by</th>
                <th className="text-left px-4 py-3">When</th>
              </tr>
            </thead>
            <tbody>
              {list.data.items.map((d) => (
                <tr key={d.id} className="border-b border-hairline/50 last:border-0">
                  <td className="px-4 py-2.5">
                    <span className="data-figure text-text-primary">{d.defect_code}</span>
                    <span className="block text-text-muted text-xs">{d.defect_description}</span>
                  </td>
                  <td className="px-4 py-2.5 text-text-muted">{d.product_type}</td>
                  <td className="px-4 py-2.5">
                    <span className="inline-flex items-center gap-1.5">
                      <span className="indicator-light" style={{ background: SEVERITY_COLOR[d.severity] }} />
                      <span className="capitalize text-text-muted">{d.severity}</span>
                    </span>
                  </td>
                  <td className="px-4 py-2.5 text-text-muted capitalize">{d.status}</td>
                  <td className="px-4 py-2.5 text-text-muted">{d.detected_by}</td>
                  <td className="px-4 py-2.5 text-text-faint data-figure text-xs">
                    {new Date(d.event_timestamp).toLocaleDateString()}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>

          <div className="flex items-center justify-between px-4 py-3 border-t border-hairline">
            <span className="panel-label">
              Page {list.data.page} — {list.data.total} total
            </span>
            <div className="flex gap-2">
              <button
                disabled={page <= 1}
                onClick={() => setPage((p) => p - 1)}
                className="px-3 py-1 text-sm border border-hairline rounded-sm text-text-muted disabled:opacity-30"
              >
                Prev
              </button>
              <button
                disabled={page * 15 >= list.data.total}
                onClick={() => setPage((p) => p + 1)}
                className="px-3 py-1 text-sm border border-hairline rounded-sm text-text-muted disabled:opacity-30"
              >
                Next
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
