import {
  LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
} from "recharts";
import PageHeader from "../components/PageHeader";
import KpiCard from "../components/KpiCard";
import { LoadingPanel, ErrorPanel } from "../components/StatePanels";
import { useApiData } from "../api/useApiData";
import { getInspectionDashboard } from "../api/inspections";

const CHART_GRID = "#3A424C";
const CHART_AXIS = "#8A9199";
const CHART_LINE = "#E8A33D";
const CHART_BAR = "#4C9A6A";

export default function InspectionDashboard() {
  const { data, isLoading, error } = useApiData(getInspectionDashboard);

  return (
    <div>
      <PageHeader
        title="Inspection Dashboard"
        subtitle="Pass rates, defect trends, and process-step throughput across the floor."
      />

      {isLoading && <LoadingPanel />}
      {error && <ErrorPanel message={error} />}

      {data && (
        <div className="space-y-8">
          <div className="grid grid-cols-4 gap-4">
            <KpiCard label="Total inspections" value={data.kpis.total_inspections.toLocaleString()} />
            <KpiCard
              label="Pass rate"
              value={`${data.kpis.pass_rate}%`}
              tone={data.kpis.pass_rate >= 95 ? "good" : data.kpis.pass_rate >= 90 ? "neutral" : "bad"}
            />
            <KpiCard label="Total defects" value={data.kpis.total_defects.toLocaleString()} />
            <KpiCard
              label="Open CAPAs"
              value={data.kpis.open_capas}
              tone={data.kpis.open_capas > 50 ? "bad" : "neutral"}
            />
          </div>

          <div className="bg-panel border border-hairline rounded-sm p-5">
            <p className="panel-label mb-4">Daily defect rate — {data.kpis.date_range_start} to {data.kpis.date_range_end}</p>
            <ResponsiveContainer width="100%" height={260}>
              <LineChart data={data.daily_trend}>
                <CartesianGrid strokeDasharray="3 3" stroke={CHART_GRID} />
                <XAxis dataKey="date" tick={{ fill: CHART_AXIS, fontSize: 11 }} minTickGap={30} />
                <YAxis tick={{ fill: CHART_AXIS, fontSize: 11 }} unit="%" />
                <Tooltip
                  contentStyle={{ background: "#242A32", border: "1px solid #3A424C", fontSize: 12 }}
                  labelStyle={{ color: "#E4E6E8" }}
                />
                <Line type="monotone" dataKey="defect_rate" stroke={CHART_LINE} strokeWidth={2} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>

          <div className="bg-panel border border-hairline rounded-sm p-5">
            <p className="panel-label mb-4">Defect rate by product / process step</p>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={data.defect_rate_by_product_step}>
                <CartesianGrid strokeDasharray="3 3" stroke={CHART_GRID} />
                <XAxis
                  dataKey={(row: { product_type: string; step_name: string }) => `${row.product_type} / ${row.step_name}`}
                  tick={{ fill: CHART_AXIS, fontSize: 10 }}
                  angle={-20}
                  textAnchor="end"
                  height={70}
                  interval={0}
                />
                <YAxis tick={{ fill: CHART_AXIS, fontSize: 11 }} unit="%" />
                <Tooltip
                  contentStyle={{ background: "#242A32", border: "1px solid #3A424C", fontSize: 12 }}
                  labelStyle={{ color: "#E4E6E8" }}
                />
                <Bar dataKey="defect_rate" fill={CHART_BAR} radius={[2, 2, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}
    </div>
  );
}
