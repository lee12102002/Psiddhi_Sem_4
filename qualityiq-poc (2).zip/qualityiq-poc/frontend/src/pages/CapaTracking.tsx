import { useState } from "react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from "recharts";
import PageHeader from "../components/PageHeader";
import KpiCard from "../components/KpiCard";
import { LoadingPanel, ErrorPanel } from "../components/StatePanels";
import { useApiData } from "../api/useApiData";
import { getCapaSummary, listCapa } from "../api/capa";

const STATUS_COLOR: Record<string, string> = {
  open: "#5B6472",
  in_progress: "#E8A33D",
  closed: "#4C9A6A",
  overdue: "#D65B4A",
};

export default function CapaTracking() {
  const [statusFilter, setStatusFilter] = useState<string | undefined>(undefined);
  const [page, setPage] = useState(1);

  const summary = useApiData(getCapaSummary);
  const list = useApiData(() => listCapa({ status: statusFilter, page, page_size: 15 }), [statusFilter, page]);

  return (
    <div>
      <PageHeader
        title="CAPA Tracking"
        subtitle="Corrective and preventive actions — status, ownership, and effectiveness."
      />

      {summary.isLoading && <LoadingPanel />}
      {summary.error && <ErrorPanel message={summary.error} />}

      {summary.data && (
        <div className="grid grid-cols-3 gap-6 mb-8">
          <KpiCard label="Total CAPAs" value={summary.data.total} />
          <KpiCard
            label="Avg. days to close"
            value={summary.data.avg_days_to_close != null ? summary.data.avg_days_to_close : "—"}
          />
          <KpiCard
            label="Overdue"
            value={summary.data.by_status.find((s) => s.status === "overdue")?.count ?? 0}
            tone="bad"
          />

          <div className="bg-panel border border-hairline rounded-sm p-5 col-span-3">
            <p className="panel-label mb-4">CAPAs by status</p>
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={summary.data.by_status} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" stroke="#3A424C" horizontal={false} />
                <XAxis type="number" tick={{ fill: "#8A9199", fontSize: 11 }} />
                <YAxis dataKey="status" type="category" tick={{ fill: "#8A9199", fontSize: 11 }} width={90} />
                <Tooltip contentStyle={{ background: "#242A32", border: "1px solid #3A424C", fontSize: 12 }} />
                <Bar dataKey="count" radius={[0, 2, 2, 0]}>
                  {summary.data.by_status.map((entry) => (
                    <Cell key={entry.status} fill={STATUS_COLOR[entry.status] ?? "#5B6472"} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}

      <div className="flex gap-2 mb-4 flex-wrap">
        <button
          onClick={() => { setStatusFilter(undefined); setPage(1); }}
          className={`px-3 py-1.5 rounded-sm text-sm border ${!statusFilter ? "border-amber text-amber" : "border-hairline text-text-muted"}`}
        >
          All
        </button>
        {["open", "in_progress", "closed", "overdue"].map((s) => (
          <button
            key={s}
            onClick={() => { setStatusFilter(s); setPage(1); }}
            className={`px-3 py-1.5 rounded-sm text-sm border capitalize ${statusFilter === s ? "border-amber text-amber" : "border-hairline text-text-muted"}`}
          >
            {s.replace("_", " ")}
          </button>
        ))}
      </div>

      {list.isLoading && <LoadingPanel />}
      {list.error && <ErrorPanel message={list.error} />}

      {list.data && (
        <div className="bg-panel border border-hairline rounded-sm overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="panel-label border-b border-hairline">
                <th className="text-left px-4 py-3">Description</th>
                <th className="text-left px-4 py-3">Linked defect</th>
                <th className="text-left px-4 py-3">Status</th>
                <th className="text-left px-4 py-3">Owner</th>
                <th className="text-left px-4 py-3">Effectiveness</th>
                <th className="text-left px-4 py-3">Opened</th>
              </tr>
            </thead>
            <tbody>
              {list.data.items.map((c) => (
                <tr key={c.id} className="border-b border-hairline/50 last:border-0">
                  <td className="px-4 py-2.5 text-text-primary max-w-xs">{c.description}</td>
                  <td className="px-4 py-2.5 data-figure text-text-muted">{c.related_defect_code ?? "—"}</td>
                  <td className="px-4 py-2.5">
                    <span className="inline-flex items-center gap-1.5">
                      <span className="indicator-light" style={{ background: STATUS_COLOR[c.status] }} />
                      <span className="capitalize text-text-muted">{c.status.replace("_", " ")}</span>
                    </span>
                  </td>
                  <td className="px-4 py-2.5 text-text-muted">{c.owner}</td>
                  <td className="px-4 py-2.5 text-text-muted capitalize">{c.effectiveness_check}</td>
                  <td className="px-4 py-2.5 text-text-faint data-figure text-xs">
                    {new Date(c.timestamp_opened).toLocaleDateString()}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>

          <div className="flex items-center justify-between px-4 py-3 border-t border-hairline">
            <span className="panel-label">Page {list.data.page} — {list.data.total} total</span>
            <div className="flex gap-2">
              <button
                disabled={page <= 1}
                onClick={() => setPage((p) => p - 1)}
                className="px-3 py-1 text-sm border border-hairline rounded-sm text-text-muted disabled:opacity-30"
              >
                Prev
              </button>
              <button
                disabled={page * 15 >= list.data.total}
                onClick={() => setPage((p) => p + 1)}
                className="px-3 py-1 text-sm border border-hairline rounded-sm text-text-muted disabled:opacity-30"
              >
                Next
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
